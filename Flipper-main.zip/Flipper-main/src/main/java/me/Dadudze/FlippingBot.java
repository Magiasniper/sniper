package me.Dadudze;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import discord4j.common.util.Snowflake;
import discord4j.core.DiscordClient;
import discord4j.core.GatewayDiscordClient;
import discord4j.core.object.entity.Message;
import discord4j.core.object.entity.channel.MessageChannel;
import discord4j.rest.util.Color;
import me.Dadudze.Objects.ArrayModel;
import me.Dadudze.Objects.AuctionHistory;
import me.Dadudze.Objects.BoughtItem;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class FlippingBot {

    public static AuctionHistory history = new AuctionHistory();
    private static String[] tracked = new String[] {"WISE_WITHER_", "POWER_WITHER_", "SHADOW_ASSASS", "LIVID_DAGG", "WITHER_GOGGLES", "PET", "BOOK"};
    private static String[] trackedNames = new String[] {"Storm's", "Necron's", "Shadow Assa", "Livid", "Shredded", "Wither Gog"};
    private static long timestamp = 0;
    private static long timestampAuctions = 0;
    public static MessageChannel channel;
    public static Message message;
    public static Message messagePets;
    private static ArrayList<String> ignored = new ArrayList<>();
    private static HashMap<String, Integer> prices = new HashMap<>();
    private static HashMap<String, Integer> priceCache = new HashMap<>();

    public static void main(String[] args) {

        readHistory();

        DiscordClient client = DiscordClient.create("ODgzNjQ2OTc5MzUwMDg5NzY5.YTM-YQ.oumUU5IiaN181GKp_tjSPGGaHMY");

        GatewayDiscordClient eventListener = client.login().block();

        long guildId = 859082767077736449L;
        long sniperBotChannelId = 883645097156157450L;

        channel = ((MessageChannel) eventListener.getGuildById(Snowflake.of(guildId)).block().getChannelById(Snowflake.of(sniperBotChannelId)).block());
        try {
            channel.getMessagesBefore(channel.getLastMessage().block().getId()).toStream().forEach(msg -> msg.delete().block());
            channel.getLastMessage().block().delete().block();
        } catch (Exception e) {}

        message = channel.createEmbed(embed -> {
            embed.setTitle("Auction Flipper Bot");
            embed.setDescription("Zapisane aukcje: " + getFormattedInteger(history.getItems().size()));
            embed.setFooter(String.format("Last Update: %s:%s", new Date().getHours(), new Date().getMinutes()), "");
        }).block();

        new Thread(() -> {
            while (true) {
                try {
                    AuctionDataEnded auctionDataBought = getAuctionDataBought();
                    if (auctionDataBought.lastUpdated != timestamp) {
                        timestamp = auctionDataBought.lastUpdated;
                        for (AuctionEnded auction : auctionDataBought.auctions) {
                            BoughtItem item = new BoughtItem(auction.price);
                            item.read(auction.item_bytes);
                            if (isTracked(item.itemId)) {
                                if (item.enchants != null) {
                                    int price = item.price;
                                    if (item.fuming != 0) price -= 900000 * item.fuming;
                                    history.addItem(new ArrayModel(price, getItemAttributes(item)));
                                }
                            }
                        }
                        message.edit(message -> {
                            message.setEmbed(embed -> {
                                embed.setTitle("Auction Flipper Bot");
                                embed.setDescription("Zapisane aukcje: " + getFormattedInteger(history.getItems().size()));
                                embed.setFooter(String.format("Last Update: %s:%s", new Date().getHours(), new Date().getMinutes()), "");
                            });
                        }).block();
                        saveHistory();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        new Thread(() -> {
            while (true) {
                try {
                    AuctionData auctionData = getAuctionData(0);
                    if (auctionData.lastUpdated != timestampAuctions) {
                        timestamp = auctionData.lastUpdated;
                        long l = System.currentTimeMillis();
                        ArrayList<Integer> looping = new ArrayList<>();
                        for (int i = 0; i < auctionData.totalPages; i++) {
                            looping.add(i);
                        }
                        looping.parallelStream().forEach(i -> {
                            auctionData.auctions.addAll(getAuctionData(i + 1).auctions);
                        });
                        long download = System.currentTimeMillis();
                        AtomicBoolean returnAll = new AtomicBoolean(false);
                        auctionData.auctions.parallelStream().forEach(auction -> {
                            if(returnAll.get()) return;
                            if (auction != null)
                                if (auction.bin) {
                                    if (isTrackedSecond(auction.item_name) || (auction.item_name.contains("[Lvl ") && auction.tier.equals("LEGENDARY"))) {
                                        BoughtItem item = new BoughtItem(auction.starting_bid);
                                        item.read(auction.item_bytes);
                                        ArrayList<String> itemAttributes = getItemAttributes(item);
                                        if (item.pet) {
                                            int level1 = history.getMedianCachedPet(item.itemId, item.petCandy, false);
                                            int level100 = history.getMedianCachedPet(item.itemId, item.petCandy, true);
                                            double exp = 0;
                                            if (item.itemId.contains("LEGENDARY"))
                                                exp = Math.min(item.petExp, 25300000) / 25300000d;
                                            if (item.itemId.contains("EPIC"))
                                                exp = Math.min(item.petExp, 18600000) / 18600000d;
                                            int clear = (int) (level1 + (level100 - level1) * exp);
                                            int lowestBin = Integer.MAX_VALUE;
                                            if(prices.containsKey(itemAttributes.toString())) {
                                                lowestBin = prices.get(itemAttributes.toString());
                                            }
                                            if(priceCache.containsKey(itemAttributes.toString())) {
                                                Integer integer = priceCache.get(itemAttributes.toString());
                                                if(integer > item.price) {
                                                    priceCache.replace(itemAttributes.toString(), item.price);
                                                }
                                            } else priceCache.put(itemAttributes.toString(), item.price);
                                            double normalCoinPerExp = (level100 - level1)/253000/100d;
                                            double coinPerExp = (item.price - level1)/Math.max(Math.min(item.petExp, 25300000)/100, 100)/100d;

                                            int finalLowestBin = lowestBin;
//                                            System.out.println(item.itemId);
//                                            System.out.println(level100 - level1);
//                                            System.out.println(item.price-clear);
//                                            System.out.println(lowestBin-item.price);
                                            if(clear-item.price > 4000000 && lowestBin-item.price > 4000000) {
                                                Message block = channel.createEmbed(creator -> {
                                                    creator.setColor(Color.GREEN);
                                                    creator.setTitle(auction.item_name + " for " + getFormattedInteger(item.price));
                                                    if (item.petCandy) {
                                                        creator.addField("Candied!", "This item has pet candy!", false);
                                                    }
                                                    creator.addField("Name", item.itemId, false);
                                                    creator.addField("Normal price: " + getFormattedInteger(clear), "Second lowest bin: " + getFormattedInteger(finalLowestBin), false);
                                                    creator.setDescription("/viewauction " + convertID(auction.uuid));
                                                    creator.setFooter("Coins per xp: " + getFormattedInteger(coinPerExp) + ", Normal coins per xp: " + getFormattedInteger(normalCoinPerExp), "");
                                                }).block();
                                                new Timer().schedule(new TimerTask() {
                                                    @Override
                                                    public void run() {
                                                        block.delete().block();
                                                    }
                                                }, 300000);
                                            }
                                            return;
                                        }
                                        int lowestBin = Integer.MAX_VALUE;
                                        if(prices.containsKey(itemAttributes.toString())) {
                                            lowestBin = prices.get(itemAttributes.toString());
                                        }
                                        if(priceCache.containsKey(itemAttributes.toString())) {
                                            Integer integer = priceCache.get(itemAttributes.toString());
                                            if(integer > item.price) {
                                                priceCache.replace(itemAttributes.toString(), item.price);
                                            }
                                        } else priceCache.put(itemAttributes.toString(), item.price);
                                        int medianPrice = history.getMedianCached(itemAttributes);
//                                        int medianPrice = history.getMedianPrice(itemAttributes);
                                        int effectivePrice = item.price;
                                        if(item.fuming != 0) effectivePrice-=900000*item.fuming;
                                        int i = item.price-(item.recomb?4000000:0)-StarringPrices.getStarPrice(item.itemId, item.stars);
                                        if (item.enchants != null) {
                                            for (Map.Entry<String, Integer> entry : item.enchants.entrySet()) {
                                                if(ExpensiveEnchants.getPrice(entry.getKey(), entry.getValue()) != 0) {
                                                    i = 0;
                                                }
                                            }
                                        }
                                        if (medianPrice - effectivePrice > 3000000) {
                                            if(lowestBin - effectivePrice < 3000000) return;
                                            if (ignored.contains(auction.uuid)) return;
                                            ignored.add(auction.uuid);
                                            int finalEffectivePrice = effectivePrice;
                                            int finalLowestBin = lowestBin;
                                            int lowestClean = -1;
                                            if(prices.containsKey(new ArrayList<>(Arrays.asList(item.itemId, "0stars")).toString())) {
                                                lowestClean = prices.get(new ArrayList<>(Arrays.asList(item.itemId, "0stars")).toString());
                                            }
                                            if(i > lowestClean) {
                                                return;
                                            }
                                            int lowestSimilar = -1;
                                            if(prices.containsKey(getSimilarItemAttributes(item).toString())) {
                                                lowestSimilar = prices.get(getSimilarItemAttributes(item).toString());
                                            }
                                            int finalLowestClean = lowestClean;
                                            int finalLowestSimilar = lowestSimilar;
                                            new Thread(() -> {
                                                try {
                                                    Socket commandSocket = new Socket(InetAddress.getLocalHost(), 45678);
                                                    DataOutputStream dos = new DataOutputStream(commandSocket.getOutputStream());
                                                    dos.writeUTF("/viewauction " + convertID(auction.uuid));
                                                    dos.writeInt(finalLowestBin);
                                                    dos.writeInt(medianPrice+(item.price- finalEffectivePrice));
                                                    dos.close();
                                                    commandSocket.close();
                                                } catch (Exception e) {}
                                            }).start();
                                            Message block = channel.createEmbed(creator -> {
                                                creator.setColor(Color.GREEN);
                                                creator.setTitle(auction.item_name + " for " + getFormattedInteger(item.price));
                                                if(item.enchants != null)
                                                    item.enchants.forEach((name, level) -> {
                                                        int price = ExpensiveEnchants.getPrice(name, level);
                                                        if (price != 0) {
                                                            creator.addField(name + " " + level, getFormattedInteger(price), false);
                                                        }
                                                    });
                                                if (item.fuming != 0) {
                                                    creator.addField(item.fuming + " fuming potato books", getFormattedInteger(900000 * item.fuming), false);
                                                }
                                                if (item.recomb) {
                                                    creator.addField("Recombobulated", getFormattedInteger(2500000), false);
                                                }
                                                if (item.stars != 0) {
                                                    creator.addField(item.stars + " stars", getFormattedInteger(StarringPrices.getStarPrice(item.itemId, item.stars)), false);
                                                }
                                                if (finalLowestSimilar != -1) {
                                                    creator.addField("Similar auction: ", getFormattedInteger(finalLowestSimilar), false);
                                                }
                                                creator.addField("Clean price: " + getFormattedInteger(finalLowestClean), "Second lowest bin: " + getFormattedInteger(finalLowestBin), false);
                                                creator.setDescription("/viewauction " + convertID(auction.uuid));
                                                creator.setFooter("Median price: " + getFormattedInteger(medianPrice+(item.price- finalEffectivePrice)), "");
                                            }).block();
                                            new Timer().schedule(new TimerTask() {
                                                @Override
                                                public void run() {
                                                    block.delete().block();
                                                }
                                            }, 300000);
                                        }
//                                        int clean = history.getMedianPrice(new ArrayList<>(Arrays.asList(item.itemId)));
//                                        if (item.pet) {
//                                            int level1 = history.getPetPrice(item.itemId, item.petCandy, false);
//                                            int level100 = history.getPetPrice(item.itemId, item.petCandy, true);
//                                            double exp = 0;
//                                            if (item.itemId.contains("LEGENDARY"))
//                                                exp = Math.min(item.petExp, 25300000) / 25300000d;
//                                            if (item.itemId.contains("EPIC"))
//                                                exp = Math.min(item.petExp, 18600000) / 18600000d;
//                                            clean = (int) (level1 + (level100 - level1) * exp);
//
//                                            if (clean - item.price > 3000000 || (clean - item.price > 2000000 && item.price/(double) level1 < 1.2)) {
//                                                double finalExp = exp;
//                                                double finalExp1 = exp;
//                                                Message block = channel.createEmbed(creator -> {
//                                                    creator.setColor(Color.GREEN);
//                                                    creator.setTitle(auction.item_name + " for " + getFormattedInteger(item.price));
//                                                    creator.addField(((int) finalExp * 100) + "%", getFormattedInteger(900000 * (level100 - level1) * finalExp1), false);
//                                                    if (item.recomb) {
//                                                        creator.addField("Recombobulated", getFormattedInteger(2500000), false);
//                                                    }
//                                                    if (item.petCandy) {
//                                                        creator.addField("Pet candy", "Candied", false);
//                                                    }
//                                                    creator.addField("Flipper id", item.itemId, false);
//                                                    creator.setDescription("/viewauction " + convertID(auction.uuid));
//                                                    creator.setFooter("Clean price: " + level1, "");
//                                                }).block();
//                                                new Timer().schedule(new TimerTask() {
//                                                    @Override
//                                                    public void run() {
//                                                        block.delete().block();
//                                                    }
//                                                }, 300000);
//                                                System.out.println(item.itemId);
//                                                System.out.println("/viewauction " + convertID(auction.uuid) + " " + getFormattedInteger(clean - item.getActualPrice()));
//                                                System.out.println("Recommended price: " + getFormattedInteger(clean - item.getActualPrice() + item.price));
//                                            }
//                                        } else if (clean - item.getActualPrice() > 4000000 || (clean - item.getActualPrice() > 2000000 && item.price/(double) clean < 1.2)) {
//                                            int finalClean = clean;
//                                            Message block = channel.createEmbed(creator -> {
//                                                creator.setColor(Color.GREEN);
//                                                creator.setTitle(auction.item_name + " for " + getFormattedInteger(item.price));
//                                                if(item.enchants != null)
//                                                item.enchants.forEach((name, level) -> {
//                                                    int price = ExpensiveEnchants.getPrice(name, level);
//                                                    if (price != 0) {
//                                                        creator.addField(name + " " + level, getFormattedInteger(price), false);
//                                                    }
//                                                });
//                                                if (item.fuming != 0) {
//                                                    creator.addField(item.fuming + " fuming potato books", getFormattedInteger(900000 * item.fuming), false);
//                                                }
//                                                if (item.recomb) {
//                                                    creator.addField("Recombobulated", getFormattedInteger(2500000), false);
//                                                }
//                                                if (item.stars != 0) {
//                                                    creator.addField(item.stars + " stars", getFormattedInteger(StarringPrices.getStarPrice(item.itemId, item.stars)), false);
//                                                }
//                                                creator.setDescription("/viewauction " + convertID(auction.uuid));
//                                                creator.setFooter("Clean price: " + getFormattedInteger(finalClean), "");
//                                            }).block();
//                                            new Timer().schedule(new TimerTask() {
//                                                @Override
//                                                public void run() {
//                                                    block.delete().block();
//                                                }
//                                            }, 300000);
//                                            System.out.println(item.itemId);
//                                            System.out.println("/viewauction " + convertID(auction.uuid) + " " + getFormattedInteger(clean - item.getActualPrice()));
//                                            System.out.println("Recommended price: " + getFormattedInteger(clean - item.getActualPrice() + item.price));
//                                        }
                                    }
                                }
                        });
                        if(!priceCache.isEmpty()) {
                            prices.clear();
                            prices.putAll(priceCache);
                            priceCache.clear();
                        }
                        history.cacheData();
                        System.out.println(System.currentTimeMillis()-l);
                        System.out.println(System.currentTimeMillis()-download);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private static boolean isTrackedSecond(String item_name) {
        for (String trackedName : trackedNames) {
            if(item_name.toUpperCase().contains(trackedName.toUpperCase())) return true;
        }
        return false;
    }

    private static ArrayList<String> getItemAttributes(BoughtItem item) {
        ArrayList<String> priceTags = new ArrayList<>();
        priceTags.add(item.itemId + (item.pet ? (int) Math.min(item.petExp/2530000, 10) == 10 : ""));
        if(item.pet) priceTags.add("PET");
        if(item.pet) {
            if(item.petCandy)
            priceTags.add("Candied");
            priceTags.add("PE:" + (int) Math.min(item.petExp/2530000, 10));
            return priceTags;
        }
        if(StarringPrices.getStarPrice(item.itemId, item.stars) != 0) priceTags.add(item.stars + "stars");
        else priceTags.add("0stars");
        if(item.recomb) priceTags.add("recomb");
        if(item.enchants != null)
        for (Map.Entry<String, Integer> entry : item.enchants.entrySet()) {
            int bookPrice = ExpensiveEnchants.getPrice(entry.getKey(), entry.getValue());
            if(bookPrice != 0) {
                priceTags.add(entry.getKey() + entry.getValue());
            }
        }
        return priceTags;
    }

    private static ArrayList<String> getSimilarItemAttributes(BoughtItem item) {
        ArrayList<String> priceTags = new ArrayList<>();
        priceTags.add(item.itemId);
        if(item.stars > 3)
        priceTags.add("5stars");
        else
        priceTags.add("0stars");
        if(item.recomb) priceTags.add("recomb");
        if(item.enchants != null)
        for (Map.Entry<String, Integer> entry : item.enchants.entrySet()) {
            int bookPrice = ExpensiveEnchants.getPrice(entry.getKey(), entry.getValue());
            if(bookPrice != 0) {
                if(entry.getKey().contains("ultimate")) {
                    if(entry.getValue() > 3) {
                        priceTags.add(entry.getKey() + "5");
                    }
                } else
                    priceTags.add(entry.getKey() + entry.getValue());
            }
        }
        return priceTags;
    }

    private static boolean isTracked(String name) {
        for (String s : tracked) {
            if (name.toUpperCase().contains(s.toUpperCase())) {
                return true;
            }
        }
        return false;
    }

    private static AuctionDataEnded getAuctionDataBought() {
        AuctionDataEnded ad = new AuctionDataEnded();
        ad.auctions = new ArrayList<>();
        try {
            ad = new Gson().fromJson(new InputStreamReader(new URL("https://api.hypixel.net/skyblock/auctions_ended").openStream(), StandardCharsets.UTF_8), AuctionDataEnded.class);
        } catch (Exception e) {}

        return ad;
    }

    private static AuctionData getAuctionData(int page) {
        AuctionData ad = new AuctionData();
        ad.auctions = new ArrayList<>();
        try {
            ad = new Gson().fromJson(new InputStreamReader(new URL("https://api.hypixel.net/skyblock/auctions?page=" + page).openStream(), StandardCharsets.UTF_8), AuctionData.class);
        } catch (Exception e) {}

        return ad;
    }

    private static void saveHistory() {
        try {
            DataOutputStream dos = new DataOutputStream(new GZIPOutputStream(new FileOutputStream("auctions")));
            dos.writeInt(history.getItems().size());
            for (ArrayModel item : history.getItems()) {
                dos.writeInt(item.getPrice());
                dos.writeByte(item.getPriceTags().size());
                for (String priceTag : item.getPriceTags()) {
                    dos.writeUTF(priceTag);
                }
            }
            dos.close();
        } catch (Exception e) {}
    }

    private static void readHistory() {
        try {
            DataInputStream dis = new DataInputStream(new GZIPInputStream(new FileInputStream("auctions")));
            int items = dis.readInt();
            for (int i = 0; i < items; i++) {
                int price = dis.readInt();
                byte tags = dis.readByte();
                ArrayList<String> priceTags = new ArrayList<>();
                for (byte b = 0; b < tags; b++) {
                    priceTags.add(dis.readUTF());
                }
                history.addItem(new ArrayModel(price, priceTags));
            }
            dis.close();
        } catch (Exception e) {}
    }

    private static int[] uuidSep = new int[] {8, 4, 4, 4, 12};

    public static String convertID(String s1) {
        return s1.substring(0, uuidSep[0]) + "-" + s1.substring(uuidSep[0], uuidSep[0]+uuidSep[1]) + "-" + s1.substring(uuidSep[0]+uuidSep[1], uuidSep[0]+uuidSep[1]+uuidSep[2]) + "-" + s1.substring(uuidSep[0]+uuidSep[1]+uuidSep[2], uuidSep[0]+uuidSep[1]+uuidSep[2]+uuidSep[3]) + "-" + s1.substring(uuidSep[0]+uuidSep[1]+uuidSep[2]+uuidSep[3], uuidSep[0]+uuidSep[1]+uuidSep[2]+uuidSep[3]+uuidSep[4]);
    }

    public static String getFormattedInteger(double i) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(' ');
        DecimalFormat formatter = new DecimalFormat("###,###.#", formatSymbols);

        return formatter.format(i);
    }
}
