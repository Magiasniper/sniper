package me.Dadudze;

import java.util.HashMap;
import java.util.Map;

public class StarringPrices {

    private static HashMap<String, Integer> map = new HashMap<String, Integer>() {{
        put("WITHER_HELMET1", 50*4000);
        put("WITHER_HELMET2", 100*4000);
        put("WITHER_HELMET3", 200*4000);
        put("WITHER_HELMET4", 350*4000);
        put("WITHER_HELMET5", 500*4000);

        put("WITHER_CHESTPLATE1", 100*4000);
        put("WITHER_CHESTPLATE2", 200*4000);
        put("WITHER_CHESTPLATE3", 350*4000);
        put("WITHER_CHESTPLATE4", 600*4000);
        put("WITHER_CHESTPLATE5", 1000*4000);

        put("WITHER_LEGGINGS1", 75*4000);
        put("WITHER_LEGGINGS2", 150*4000);
        put("WITHER_LEGGINGS3", 250*4000);
        put("WITHER_LEGGINGS4", 400*4000);
        put("WITHER_LEGGINGS5", 700*4000);

        put("WITHER_BOOTS1", 50*4000);
        put("WITHER_BOOTS2", 100*4000);
        put("WITHER_BOOTS3", 200*4000);
        put("WITHER_BOOTS4", 350*4000);
        put("WITHER_BOOTS5", 500*4000);

        put("LIVID_DAGGER1", 30*4000);
        put("LIVID_DAGGER2", 60*4000);
        put("LIVID_DAGGER3", 120*4000);
        put("LIVID_DAGGER4", 250*4000);
        put("LIVID_DAGGER5", 400*4000);

        put("OF_TRUTH1", 50*4000);
        put("OF_TRUTH2", 100*4000);
        put("OF_TRUTH3", 200*4000);
        put("OF_TRUTH4", 400*4000);
        put("OF_TRUTH5", 800*4000);

        put("ASSASSIN_HELMET1", 25*4000);
        put("ASSASSIN_HELMET2", 50*4000);
        put("ASSASSIN_HELMET3", 100*4000);
        put("ASSASSIN_HELMET4", 200*4000);
        put("ASSASSIN_HELMET5", 300*4000);

        put("ASSASSIN_CHESTPLATE1", 35*4000);
        put("ASSASSIN_CHESTPLATE2", 75*4000);
        put("ASSASSIN_CHESTPLATE3", 150*4000);
        put("ASSASSIN_CHESTPLATE4", 300*4000);
        put("ASSASSIN_CHESTPLATE5", 500*4000);

        put("ASSASSIN_LEGGINGS1", 30*4000);
        put("ASSASSIN_LEGGINGS2", 60*4000);
        put("ASSASSIN_LEGGINGS3", 120*4000);
        put("ASSASSIN_LEGGINGS4", 250*4000);
        put("ASSASSIN_LEGGINGS5", 400*4000);

        put("ASSASSIN_BOOTS1", 20*4000);
        put("ASSASSIN_BOOTS2", 50*4000);
        put("ASSASSIN_BOOTS3", 100*4000);
        put("ASSASSIN_BOOTS4", 200*4000);
        put("ASSASSIN_BOOTS5", 300*4000);
    }};

    public static int getStarPrice(String name, int stars) {
        int price = 0;
        for (int i = 0; i < stars; i++) {
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                String key = entry.getKey();
                if(name.contains(key.substring(0, key.length()-2))) {
                    if(key.contains(String.valueOf(i+1))) {
                        price += entry.getValue();
                    }
                }
            }
        }
        return price;
    }

}
