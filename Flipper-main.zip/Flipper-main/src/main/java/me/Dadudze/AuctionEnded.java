package me.Dadudze;

public class AuctionEnded {

    String auction_id;
    String buyer;
    String item_bytes;
    String itemName;
    String rarity;
    boolean bin;
    int price;
    long timestamp;

}
