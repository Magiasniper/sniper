package me.Dadudze;

import java.util.ArrayList;

public class AuctionData {

    public ArrayList<Auction> auctions = new ArrayList<>();
    public boolean success;
    public int totalPages;
    public int totalAuctions;
    public int page;
    public long lastUpdated;

}
