package me.Dadudze.Objects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Predicate;

public class AuctionHistory {

    private HashMap<String, Integer> priceCache = new HashMap<>();
    private ArrayList<ArrayModel> items = new ArrayList<>();

    public ArrayList<ArrayModel> getItems() {
        return items;
    }

    public void addItem(ArrayModel item) {
        items.add(item);
    }

    public void cacheData() {
        priceCache.clear();
        ArrayList<String> cached = new ArrayList<>();

        if(items.size() > 10000) {
            System.out.println("cleanup");
            ArrayList<ArrayModel> items = new ArrayList<>();

            for (ArrayModel item : ((ArrayList<ArrayModel>) items.clone())) {
                String id = item.getPriceTags().toString();
                if (!cached.contains(id)) {
                    cached.add(id);
                    int medianPrice = getMedianPrice(item.getPriceTags());
                    priceCache.put(id, medianPrice);
                    items.add(new ArrayModel(medianPrice, item.getPriceTags()));
                }
            }
            this.items.clear();
            this.items.addAll(items);
        } else {
            for (ArrayModel item : ((ArrayList<ArrayModel>) items.clone())) {
                String id = item.getPriceTags().toString();
                if (!cached.contains(id) && !cached.contains(id + id.contains("PE:10"))) {
                    if(id.contains("PE:")) {
                        ArrayList<String> copyTags = new ArrayList<>();
                        int levelT = -1;
                        for (String priceTag : item.getPriceTags()) {
                            if(priceTag.startsWith("PE:")) {
                                int level = Integer.parseInt(priceTag.split(":")[1]);
                                if(level == 10) {
                                    levelT = 1;
                                }
                                if(level < 4) {
                                    levelT = 0;
                                }
                                continue;
                            }
                            copyTags.add(priceTag);
                        }
                        if(levelT != -1) {
                            cached.add(copyTags.toString() + (levelT == 1));
                            priceCache.put(copyTags.toString() + (levelT == 1), getMedianPrice(item.getPriceTags()));
                            continue;
                        }
                    }
                    cached.add(id);
                    priceCache.put(id, getMedianPrice(item.getPriceTags()));
                }
            }
        }
    }

    public int getMedianPrice(ArrayList<String> priceTags) {
        ArrayList<Integer> price = new ArrayList<>();
        for (ArrayModel item : ((ArrayList<ArrayModel>) items.clone())) {
            if(arrayEquals(item.getPriceTags(), priceTags)) {
                price.add(item.getPrice());
            }
        }
        if(price.size() == 0) return 0;
        price.sort((i, i2) -> i-i2);
        return price.get(price.size()/2);
    }

    public int getMedianCached(ArrayList<String> priceTags) {
        return priceCache.getOrDefault(priceTags.toString(), 0);
    }

    public int getMedianCachedPet(String name, boolean candy, boolean level100) {
        ArrayList<String> priceTags = new ArrayList<>();
        priceTags.add(name);
        priceTags.add("PET");
        if(candy) priceTags.add("Candied");
        return priceCache.getOrDefault(priceTags.toString() + level100, 0);
    }

    public int getBookPrice(String enchantment, int level) {
        ArrayList<Integer> price = new ArrayList<>();
        for (ArrayModel item : ((ArrayList<ArrayModel>) items.clone())) {
            if(item.getPriceTags().contains("BOOK" + enchantment + level)) {
                price.add(item.getPrice());
            }
        }
        if(price.size() == 0) return 0;
        price.sort((i, i2) -> i-i2);
        return price.get(price.size()/2);
    }

    private boolean arrayEquals(ArrayList list1, ArrayList list2) {
        if(list1.size() != list2.size()) return false;
        for (Object o : list1) {
            if(!list2.contains(o)) return false;
        }
        return true;
    }

    private boolean arrayEqualsPet(ArrayList list1, ArrayList list2) {
        if(list1.stream().filter(s -> !((String) s).startsWith("PE")).count() != list2.stream().filter(s -> !((String) s).startsWith("PE")).count()) return false;
        for (Object o : list1) {
            if(((String) o).startsWith("PE")) continue;
            if(!list2.contains(o)) return false;
        }
        return true;
    }

    public int getPetPrice(String name, boolean candy, boolean level100) {
        ArrayList<Integer> price = new ArrayList<>();
        ArrayList<String> priceTags = new ArrayList<>();
        priceTags.add(name);
        if(candy) priceTags.add("Candied");
        for (ArrayModel item : ((ArrayList<ArrayModel>) items.clone())) {
            if(arrayEqualsPet(item.getPriceTags(), priceTags)) {
                if(level100) {
                    int xp = Integer.parseInt(item.getPriceTags().stream().filter(s -> s.startsWith("PE:")).findFirst().get().replaceFirst("PE:", ""));
                    if(xp == 10)
                    price.add(item.getPrice());
                } else {
                    int xp = Integer.parseInt(item.getPriceTags().stream().filter(s -> s.startsWith("PE:")).findFirst().get().replaceFirst("PE:", ""));
                    if(xp < 4)
                    price.add(item.getPrice());
                }
            }
        }
        if(price.size() == 0) return 0;
        price.sort((i, i2) -> i-i2);
        return price.get(price.size()/2);
    }

    public String toString(ArrayList<String> list) {
        Iterator<String> it = list.iterator();
        if (! it.hasNext())
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (;;) {
            String e = it.next();
            if(e.startsWith("PE:")) continue;
            sb.append(e);
            if (! it.hasNext())
                return sb.append(']').toString();
            sb.append(',').append(' ');
        }
    }

}
