package me.Dadudze.Objects;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import me.Dadudze.ExpensiveEnchants;
import me.Dadudze.StarringPrices;
import me.nullicorn.nedit.NBTReader;
import me.nullicorn.nedit.type.NBTCompound;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class BoughtItem {

    public int price;
    public int stars = 0;
    public int fuming;
    public boolean recomb;
    public boolean pet = false;
    public String itemId;
    public HashMap<String, Integer> enchants;

    public boolean petCandy;
    public long petExp;

    public BoughtItem(int price) {
        this.price = price;
    }

    public void read(String bytes) {
        NBTCompound nbt = null;
        try {
            nbt = ((NBTCompound) NBTReader.readBase64(bytes).entrySet().iterator().next().getValue()).getList("i").getCompound(0).getCompound("tag");
        } catch (IOException e) {
            e.printStackTrace();
        }
        NBTCompound extraAttributes = nbt.getCompound("ExtraAttributes");
        itemId = extraAttributes.getString("id", "UNKNOWN");
        if (itemId.equals("PET")) {
            pet = true;
            JsonObject object = new JsonParser().parse(extraAttributes.getString("petInfo", "{}")).getAsJsonObject();
            itemId = object.get("tier").getAsString() + "_" + object.get("type").getAsString();
            if(object.has("heldItem"))
            if(object.get("heldItem").getAsString().equals("PET_ITEM_TIER_BOOST")) itemId = "TIERBOOSTED_" + itemId;
            if(object.has("petCandy"))
            petCandy = object.get("petCandy").getAsInt() > 0;
            if(object.has("petExp"))
            petExp = object.get("petExp").getAsLong();

        } else {
            stars = extraAttributes.getInt("dungeon_item_level", 0);
            fuming = Math.max(10, extraAttributes.getInt("dungeon_item_level", 0)) - 10;
            recomb = extraAttributes.getInt("rarity_upgrades", 0) == 1;
            enchants = ((HashMap<String, Integer>) extraAttributes.get("enchantments"));
        }
    }

    public boolean isClean() {
        if (!recomb && stars == 0 && fuming == 0) {
            AtomicInteger sum = new AtomicInteger();
            if(enchants != null)
            enchants.forEach((name, level) -> {
                sum.addAndGet(ExpensiveEnchants.getPrice(name, level));
            });
            if(sum.get() == 0) return true;
        }
        return false;
    }

    public int getActualPrice() {
        int priceCopy = price;
        if(recomb) priceCopy -= 2500000;
        priceCopy -= 900000*fuming;
        if(enchants != null)
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            priceCopy -= ExpensiveEnchants.getPrice(entry.getKey(), entry.getValue());
        }
        priceCopy -= StarringPrices.getStarPrice(itemId, stars);

        return priceCopy;
    }

}
