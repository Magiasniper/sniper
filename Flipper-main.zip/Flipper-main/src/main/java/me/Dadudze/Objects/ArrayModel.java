package me.Dadudze.Objects;

import java.util.ArrayList;

public class ArrayModel {

    private int price;
    private ArrayList<String> priceTags = new ArrayList<>();

    public ArrayModel(int aboveMedian, ArrayList<String> priceTags) {
        this.price = aboveMedian;
        this.priceTags = priceTags;
    }

    public ArrayList<String> getPriceTags() {
        return priceTags;
    }

    public int getPrice() {
        return price;
    }
}
