package me.Dadudze;

import java.util.HashMap;

public class ExpensiveEnchants {

    public static HashMap<String, Integer> enchants = new HashMap<String, Integer>() {{
        put("execute", 5);
        put("PROSECUTE", 5);
        put("dragon_hunter", 4);
        put("vicious", 0);
        put("giant_killer", 5);
        put("sharpness", 5);
        put("growth", 5);
        put("protection", 5);
        put("ultimate_legion", 0);
        put("ultimate_swarm", 0);
        put("ultimate_soul_eater", 0);
    }};

    public static int getPrice(String name, int level) {
        if(name.contains("ultimate")) {
            if(enchants.containsKey(name)) {
                return 1;
//                return (int) (Math.pow(2, level-1)*FlippingBot.history.getBookPrice(name, 1));
            }
        }
        if(!enchants.containsKey(name) || level <= enchants.get(name)) {
            return 0;
        }
//        return FlippingBot.history.getBookPrice(name, level);
        return 1;
    }

}
