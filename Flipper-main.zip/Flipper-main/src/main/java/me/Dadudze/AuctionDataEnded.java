package me.Dadudze;

import java.util.ArrayList;

public class AuctionDataEnded {

    public ArrayList<AuctionEnded> auctions = new ArrayList<>();
    public long lastUpdated;
}
