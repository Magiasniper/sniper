package me.Dadudze;

public class Auction {

    String uuid;
    String item_name;
    String item_lore;
    String tier;
    String item_bytes;
    boolean bin = false;
    int starting_bid;
    int highest_bid_amount;
    long start;
    long end;

}
